<?
if($_SERVER['REQUEST_URI'] !== '/TWC/styleguide/') {
  include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/header.php');
}
?>
<div class="askAmy right">
    <div class="amy mobile-hidden">
        <img src="includes/amy.png" alt="">
    </div>
    <div class="askFormWrapper">
        <form>
            <label for="askTWC" class="book text-link">
                Ask TWC - Virtual Assistant
            </label>
            <div class="clear mobile-only"></div>
            <div class="inputWrapper">
                <input id="askTWC" name="askTWC" type="text" placeholder="Type your question here...">
                <div class="cta omega twc-icon-after icon-andgle-right">
                    <a href="#" name="">
                        <span>Go</span>
                    </a>
                </div>
            </div>
            <div class="suggestionBox">
                <div class="suggestionBoxContent">
                    <p class="closeSuggestion"></p>
                    <p class="b">
                        Find the answers to questions our customers ask most often, such as:
                    </p>
                    <ul class="bulleted">
                        <li>
                            <a href="#">Can I purchase my own internet modem?</a>
                        </li>
                        <li>
                            <a href="#">How do I get a new remote control?</a>
                        </li>
                        <li>
                            <a href="#">How do I make a payment?</a>
                        </li>
                        <li>
                            <a href="#">What if I have problems logging in?</a>
                        </li>
                        <li>
                            <a href="#">Where can I replace or return my TWC Internet hardware?</a>
                        </li>
                    </ul>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="clear"></div>
<!-- <hr class="solid">
<div class="50-50 section columnControl">
  <div class="parsys_column twc-col2_5050">
    <div class="parsys parsys0 twc-col2_5050-c0 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col2_5050-c1 parsys_column">
      <div class="parbase section">
        <h3>In 50/50 CC</h3>
        <div class="askAmy right">
            <div class="amy mobile-hidden">
                <figure>
                    <img src="includes/amy.png" alt="">
                </figure>
            </div>
            <div class="askFormWrapper">
                <form>
                    <label for="askTWC" class="book text-link">
                        Ask TWC - Virtual Assistant
                    </label>
                    <div class="clear mobile-only"></div>
                    <div class="inputWrapper">
                        <input id="askTWC" name="askTWC" type="text" placeholder="Type your question here...">
                        <div class="cta omega twc-icon-after icon-andgle-right">
                            <a href="#" name="">
                                <span>Go</span>
                            </a>
                        </div>
                    </div>
                    <div class="suggestionBox">
                        <div class="suggestionBoxContent">
                            <p class="closeSuggestion"></p>
                            <p class="b">
                                Find the answers to questions our customers ask most often, such as:
                            </p>
                            <ul class="bulleted">
                                <li>
                                    <a href="#">Can I purchase my own internet modem?</a>
                                </li>
                                <li>
                                    <a href="#">How do I get a new remote control?</a>
                                </li>
                                <li>
                                    <a href="#">How do I make a payment?</a>
                                </li>
                                <li>
                                    <a href="#">What if I have problems logging in?</a>
                                </li>
                                <li>
                                    <a href="#">Where can I replace or return my TWC Internet hardware?</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      </div>
      <div class="new section"></div>
    </div>
  </div>
  <div class="columnClear"></div>
</div>
<hr class="solid">
<div class="33-33-33 section columnControl">
  <div class="parsys_column twc-col3_333333">
    <div class="parsys parsys0 twc-col3_333333-c0 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col3_333333-c1 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col3_333333-c2 parsys_column">
      <div class="parbase section">
        <h3>In 33/33/33 CC</h3>
        <div class="askAmy right">
            <div class="amy mobile-hidden">
                <figure>
                    <img src="includes/amy.png" alt="">
                </figure>
            </div>
            <div class="askFormWrapper">
                <form>
                    <label for="askTWC" class="book text-link">
                        Ask TWC - Virtual Assistant
                    </label>
                    <div class="clear mobile-only"></div>
                    <div class="inputWrapper">
                        <input id="askTWC" name="askTWC" type="text" placeholder="Type your question here...">
                        <div class="cta omega twc-icon-after icon-andgle-right">
                            <a href="#" name="">
                                <span>Go</span>
                            </a>
                        </div>
                    </div>
                    <div class="suggestionBox">
                        <div class="suggestionBoxContent">
                            <p class="closeSuggestion"></p>
                            <p class="b">
                                Find the answers to questions our customers ask most often, such as:
                            </p>
                            <ul class="bulleted">
                                <li>
                                    <a href="#">Can I purchase my own internet modem?</a>
                                </li>
                                <li>
                                    <a href="#">How do I get a new remote control?</a>
                                </li>
                                <li>
                                    <a href="#">How do I make a payment?</a>
                                </li>
                                <li>
                                    <a href="#">What if I have problems logging in?</a>
                                </li>
                                <li>
                                    <a href="#">Where can I replace or return my TWC Internet hardware?</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      </div>
      <div class="new section"></div>
    </div>
  </div>
  <div class="columnClear"></div>
</div>
<hr class="solid">
<div class="25-25-25-25 section columnControl">
  <div class="parsys_column twc-col4_25252525">
    <div class="parsys parsys0 twc-col4_25252525-c0 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col4_25252525-c1 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col4_25252525-c2 parsys_column">
      <div class="parbase section">

      </div>
      <div class="new section"></div>
    </div>
    <div class="parsys parsys1 twc-col4_25252525-c3 parsys_column">
      <div class="parbase section">
        <div class="askAmy right">
            <div class="amy mobile-hidden">
                <figure>
                    <img src="includes/amy.png" alt="">
                </figure>
            </div>
            <div class="askFormWrapper">
                <form>
                    <label for="askTWC" class="book text-link">
                        Ask TWC - Virtual Assistant
                    </label>
                    <div class="clear mobile-only"></div>
                    <div class="inputWrapper">
                        <input id="askTWC" name="askTWC" type="text" placeholder="Type your question here...">
                        <div class="cta omega twc-icon-after icon-andgle-right">
                            <a href="#" name="">
                                <span>Go</span>
                            </a>
                        </div>
                    </div>
                    <div class="suggestionBox">
                        <div class="suggestionBoxContent">
                            <p class="closeSuggestion"></p>
                            <p class="b">
                                Find the answers to questions our customers ask most often, such as:
                            </p>
                            <ul class="bulleted">
                                <li>
                                    <a href="#">Can I purchase my own internet modem?</a>
                                </li>
                                <li>
                                    <a href="#">How do I get a new remote control?</a>
                                </li>
                                <li>
                                    <a href="#">How do I make a payment?</a>
                                </li>
                                <li>
                                    <a href="#">What if I have problems logging in?</a>
                                </li>
                                <li>
                                    <a href="#">Where can I replace or return my TWC Internet hardware?</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      </div>
      <div class="new section"></div>
    </div>
  </div>
  <div class="columnClear"></div>
</div> -->
<?php include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/tileList.php'); ?>
<p>Filler text - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam, perspiciatis aut illum voluptate! Totam cupiditate exercitationem quia sequi quo quod explicabo. Nulla veniam animi, repellendus officiis provident labore sapiente nihil hic quos sed, vitae. Facere odit quae corporis officiis possimus architecto! Sequi eum modi quam temporibus accusantium consectetur fugit, velit facilis tempore totam est reprehenderit maxime vero labore corrupti debitis, necessitatibus eos. Explicabo distinctio consequuntur nam ad reprehenderit enim suscipit, non eligendi rerum? Quos a odio minus debitis architecto quia ad praesentium, corporis placeat facilis iure. Nam magni enim optio dolorum, ut sapiente voluptate? Ratione, saepe, consequatur. Molestiae fuga laboriosam a, amet veniam quia similique soluta labore unde dolore at architecto cumque veritatis temporibus odit quisquam, et. Laudantium perspiciatis aspernatur repellendus sequi nemo laborum, ducimus, atque maxime ipsa ipsam doloribus quis autem unde corporis necessitatibus provident doloremque quaerat aut impedit animi, minima. Quas atque earum cum. Quas tenetur sapiente possimus.</p>

<?
if($_SERVER['REQUEST_URI'] !== '/TWC/styleguide/') {
  include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/footer.php');
}
?>